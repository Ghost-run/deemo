let gameOptions = {
    platformGapRange: [200, 400],//平台间隙范围
    platformWidthRange: [50, 150],//平台宽度范围
    platformHeight: 600,//平台高度
    playerWidth: 32,//玩家宽度
    playerHeight: 64,//玩家高度
    poleWidth: 8,//杆子宽度
    growTime: 500,//拉长时间
    rotateTime: 500,//旋转时间
    walkTime: 3,//移动时间
    fallTime: 500,//掉落时间
    scrollTime: 250//滚动时间
}
const IDLE = 0;
const WAITING = 1;
const GROWING = 2;
const WALKING = 3;
window.onload = () => {
    let gameConfig = {
        type: Phaser.AUTO,
        scale: {
            width: 750,
            height: 1080,
            mode: Phaser.Scale.FIT,
            autoCenter: Phaser.Scale.CENTER_BOTH
        },
        scene: [Play],
        backgroundColor: 0x0c88c7
    }
    game = new Phaser.Game(gameConfig);
    window.focus();

}
class Play extends Phaser.Scene {
    constructor() {
        super("play");
    }
    preload() {
        this.load.setPath('../assets')

        this.load.image("tile", "tile.png");
        this.load.image("coin", "coin.png");
        this.load.image("player", "player.png");
    }
    create() {
        this.addPlatforms();
        this.addPlayer();
        this.addPole();
        this.addCoin();
        this.gameMode = IDLE;
        this.input.on("pointerdown", this.grow, this);
        this.input.on("pointerup", this.stop, this);
    }

    addPlatform(posX) {
        let platform = this.add.sprite(posX, this.scale.height - gameOptions.platformHeight, "tile");
        platform.displayWidth = (gameOptions.platformWidthRange[0] + gameOptions.platformWidthRange[1]) / 2;
        // platform.displayWidth =Phaser.Math.Between(gameOptions.platformWidthRange[0], gameOptions.platformWidthRange[1]);
        platform.displayHeight = gameOptions.platformHeight;
        platform.alpha = 0.7;
        platform.setOrigin(0, 0);
        return platform
    }
    addPlatforms() {
        this.mainPlatform = 0;
        this.platforms = [];
        this.platforms.push(this.addPlatform(0));
        // this.platforms.push(this.addPlatform(this.scale.width-200));
        this.platforms.push(this.addPlatform(this.scale.width));
        this.tweenPlatform();

    }
    tweenPlatform() {
        let destination = this.platforms[this.mainPlatform].displayWidth + Phaser.Math.Between(gameOptions.platformGapRange[0], gameOptions.platformGapRange[1]);
        let size = Phaser.Math.Between(gameOptions.platformWidthRange[0], gameOptions.platformWidthRange[1]);
        this.tweens.add({
            targets: [this.platforms[1 - this.mainPlatform]],
            props: {
                x: destination,
                displayWidth: size

            },

            duration: gameOptions.scrollTime,
            callbackScope: this,
            onComplete: function () {
                this.gameMode = WAITING;
                this.placeCoin();
            }
        })
    }
    addCoin() {
        this.coin = this.add.sprite(0, this.scale.height - (gameOptions.platformHeight - gameOptions.playerHeight / 2), "coin");
        this.coin.visible = false;
        this.placeCoin();
    }
    placeCoin() {
        this.coin.x = Phaser.Math.Between(this.platforms[this.mainPlatform].getBounds().right + 10, this.platforms[1 - this.mainPlatform].getBounds().left - 10);
        this.coin.visible = true;
    }

    addPlayer() {
        // this.player = this.add.sprite(100, this.scale.height - gameOptions.platformHeight, "player");
        this.player = this.add.sprite(this.platforms[this.mainPlatform].displayWidth - gameOptions.poleWidth, this.scale.height - gameOptions.platformHeight, "player");
        this.player.setOrigin(1, 1);
    }
    addPole() {
        // this.pole =this.add.sprite(110, this.scale.height - gameOptions.platformHeight, "tile");
        this.pole = this.add.sprite(this.platforms[this.mainPlatform].displayWidth, this.scale.height - gameOptions.platformHeight, "tile");
        this.pole.setOrigin(1, 1);
        this.pole.displayWidth = gameOptions.poleWidth;
        this.pole.displayHeight = gameOptions.playerHeight / 4;
    }

    update() {
        if (this.player.flipY) {
            let playerBound = this.player.getBounds();
            let coinBound = this.coin.getBounds();
            let platformBound = this.platforms[1 - this.mainPlatform].getBounds();
            if (Phaser.Geom.Rectangle.Intersection(playerBound, platformBound).width != 0) {
                this.walkTween.stop();
                this.gameMode = IDLE;
                this.shakeAndRestart();
            }
            if (this.coin.visible && Phaser.Geom.Rectangle.Intersection(playerBound, coinBound).width != 0) {
                this.coin.visible = false;
            }
        }

    }
    grow() {
        if (this.gameMode == WAITING) {
            this.gameMode = GROWING;
            this.growTween = this.tweens.add({
                targets: [this.pole],
                displayHeight: gameOptions.platformGapRange[1] + gameOptions.platformWidthRange[1],
                duration: gameOptions.growTime
            });
        }
      

    }
    stop() {
        if (this.gameMode != GROWING)
            return;
        this.gameMode = IDLE;
        this.growTween.stop();

        if (this.pole.displayHeight > (this.platforms[1 - this.mainPlatform].x - this.pole.x)) {
            this.tweens.add({
                targets: [this.pole],
                angle: 90,
                duration: gameOptions.rotateTime,
                ease: "Bounce.easeOut",
                callbackScope: this,
                onComplete: () => {
                    this.gameMode = WALKING;
                    if (this.pole.displayHeight < this.platforms[1 - this.mainPlatform].x + this.platforms[1 - this.mainPlatform].displayWidth - this.pole.x) {
                        this.walkTween = this.tweens.add({
                            targets: [this.player],
                            x: this.platforms[1 - this.mainPlatform].x + this.platforms[1 - this.mainPlatform].displayWidth - this.pole.displayWidth,
                            duration: gameOptions.walkTime * this.pole.displayHeight,
                            callbackScope: this,
                            onComplete: () => {
                                this.coin.visible = false;
                                this.tweens.add({
                                    targets: [this.player, this.pole, this.platforms[1 - this.mainPlatform], this.platforms[this.mainPlatform]],
                                    props: {
                                        x: {
                                            value: "-= " + this.platforms[1 - this.mainPlatform].x
                                        }
                                    },
                                    duration: gameOptions.scrollTime,
                                    callbackScope: this,
                                    onComplete: () => {
                                        this.prepareNextMove();
                                    }
                                })
                            }
                        })
                    }
                    else {
                        this.platformTooLong();
                    }
                }
            })
        }
        else {
            this.platformTooShort();
        }
    }
    platformTooLong() {
        this.gameMode = WALKING;
        this.walkTween = this.tweens.add({
            targets: [this.player],
            x: this.pole.x + this.pole.displayHeight + this.player.displayWidth,
            duration: gameOptions.walkTime * this.pole.displayHeight,
            callbackScope: this,
            onComplete: () => {
                this.tweens.add({
                    targets: [this.player],
                    angle: 180,
                    duration: gameOptions.rotateTime,
                    ease: "Cubic.easeIn"
                });
                this.fallAndDie();

            }
        });
    }
    platformTooShort() {
        this.tweens.add({
            targets: [this.pole],
            angle: 90,
            duration: gameOptions.rotateTime,
            ease: "Cubic.easeIn",
            callbackScope: this,
            onComplete: () => {
                this.gameMode = WALKING;
                this.tweens.add({
                    targets: [this.player],
                    x: this.pole.x + this.pole.displayHeight,
                    duration: gameOptions.walkTime * this.pole.displayHeight,
                    callbackScope: this,
                    onComplete: () => {
                        this.tweens.add({
                            targets: [this.player],
                            angle: 180,
                            duration: gameOptions.rotateTime,
                            ease: "Cubic.easeIn"
                        })
                        this.fallAndDie();
                    }
                })
            }
        })
    }
    fallAndDie() {
        this.gameMode = IDLE;
        this.tweens.add({
            targets: [this.player],
            y: this.scale.height + this.player.displayHeight * 2,
            duration: gameOptions.fallTime,
            ease: "Cubic.easeIn",
            callbackScope: this,
            onComplete: function () {
                this.shakeAndRestart();
            }
        })
    }
    prepareNextMove() {
        this.gameMode = IDLE;
        this.platforms[this.mainPlatform].x = this.scale.width;
        this.mainPlatform = 1 - this.mainPlatform;
        this.tweenPlatform();
        this.pole.angle = 0;
        this.pole.x = this.platforms[this.mainPlatform].displayWidth;
        this.pole.displayHeight = gameOptions.poleWidth;
    }
    shakeAndRestart() {
        this.cameras.main.shake(800, 0.01);
        this.time.addEvent({
            delay: 2000,
            callbackScope: this,
            callback: function () {
                this.scene.start("play");
            }
        })
    }
}

