export default class PlayerSquare extends Phaser.GameObjects.Sprite {
	constructor(scene, x, y, key) {
		super(scene, x, y, key);
        this.successful = 0;
        this.setScale(0.2);
	}
}
