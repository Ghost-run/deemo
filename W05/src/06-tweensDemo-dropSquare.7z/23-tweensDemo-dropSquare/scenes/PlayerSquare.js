import { GAMEOPTIONS } from "./GameOptions.js";

class SquareText extends Phaser.GameObjects.BitmapText {
  constructor(scene, x, y, font, text, size, tintColor) {
    //let tintColor = Phaser.Utils. Array.GetRandom(GAMEOPTIONS.bgColors);
    super(scene, x, y, font, text, size);
    this.setOrigin(0.5);
    this.setScale(0.4);
    this.setTint(tintColor);
    scene.add.existing(this);
  }
  updateText(text) {
    this.setText(text);
  }
}
export default class PlayerSquare {
  constructor(scene, x, y, key, tintColor) {
    this.square = scene.add.sprite(x, y, key);

    this.square.setScale(0.2);
    this.scene = scene;
    this.targetY = 150;
    this.successful = 0;

    this.squareText = new SquareText(
      scene,
      this.square.x,
      this.square.y,
      "font",
      0,
      120,
      tintColor
    );

    this.squareTweenTargets = [this.square, this.squareText];
  }
  get displayHeight() {
    return this.square.displayHeight;
  }
  get displayWidth() {
    return this.square.displayWidth;
  }
  updateText(text) {
    this.squareText.updateText(text);
  }
  grow() {
    this.growTween = this.scene.tweens.add({
      targets: this.squareTweenTargets,
      scaleX: 1,
      scaleY: 1,
      duration: GAMEOPTIONS.growTime,
    });
  }
  stop() {
    if (!!this.growTween) this.growTween.stop();
    if (!!this.rotateTween) this.rotateTween.stop();
    this.rotateTween = this.scene.tweens.add({
      targets: this.squareTweenTargets,
      angle: 0,
      duration: 300,
      ease: "Cubic.easeOut",
      callbackScope: this,
      onComplete: () => {
        this.isPass();
      },
    });
  }
  back() {
    //let self = this;
    this.scene.tweens.add({
      targets: this.squareTweenTargets,
      y: this.targetY,
      scaleX: 0.2,
      scaleY: 0.2,
      angle: 50,
      duration: 500,
      ease: "Cubic.easeOut",
      callbackScope: this,
      onComplete: () => {
        //console.log(this);
        this.rotateTween = this.scene.tweens.add({
          targets: this.squareTweenTargets,
          angle: 40,
          duration: 300,
          yoyo: true,
          repeat: -1,
        });
        this.scene.afterBackTop();
      },
    });
  }
  isPass() {
    let scene = this.scene;
    if (this.displayWidth <= scene.rightSquare.x - scene.leftSquare.x) {
      scene.tweens.add({
        targets: this.squareTweenTargets,
        y: scene.game.config.height + this.displayWidth,
        duration: 600,
        ease: "Cubic.easeIn",
        callbackScope: this,
        onComplete: () => {
          scene.help.levelText.text = "Oh no!!!";
          scene.gameOver();
        },
      });
    } else {
      if (this.displayWidth <= scene.rightWall.x - scene.leftWall.x) {
        this.fallAndBounce(true);
      } else {
        this.fallAndBounce(false);
      }
    }
  }
  fall(success, destY, message) {
    let scene = this.scene;
    scene.tweens.add({
      targets: this.squareTweenTargets,
      y: destY,
      duration: 600,
      ease: "Bounce.easeOut",
      callbackScope: this,
      onComplete: () => {
        scene.help.levelText.text = message;
        if (!success) {
          scene.gameOver();
        } else {
          scene.time.addEvent({
            delay: 1000,
            callback: scene.afterStoped,
            callbackScope: scene,
          });
        }
      },
    });
  }

  fallAndBounce(success) {
    let scene = this.scene;
    let destY =
      scene.game.config.height -
      scene.leftSquare.displayHeight -
      this.displayHeight / 2;
    let message = "Yeah!!!!";
    if (success) {
      this.successful++;
    } else {
      destY =
        scene.game.config.height -
        scene.leftSquare.displayHeight -
        scene.leftWall.displayHeight -
        this.displayHeight / 2;
      message = "Oh no!!!!";
    }
    this.fall(success, destY, message);
  }
}
