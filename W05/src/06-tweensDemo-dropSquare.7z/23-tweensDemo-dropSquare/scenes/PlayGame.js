import { GAMEOPTIONS } from "./GameOptions.js";
import * as gameMode from "./GameModes.js";
import PlayerSquare from "./PlayerSquare.js";

import GameWall from "./GameWall.js";
import HelpInfo from "./HelpInfo.js";
export default class PlayGame extends Phaser.Scene {
  constructor() {
    super("PlayGame");
  }
  create() {
    this.saveData =
      localStorage.getItem(GAMEOPTIONS.localStorageName) == null
        ? { level: 1 }
        : JSON.parse(localStorage.getItem(GAMEOPTIONS.localStorageName));
    let tintColor = Phaser.Utils.Array.GetRandom(GAMEOPTIONS.bgColors);
    this.cameras.main.setBackgroundColor(tintColor);
    this.leftSquare = new GameWall(
      this,
      0,
      this.game.config.height,
      "base",
      new Phaser.Math.Vector2(1, 1)
    );
    this.rightSquare = new GameWall(
      this,
      this.game.config.width,
      this.game.config.height,
      "base",
      new Phaser.Math.Vector2(0, 1)
    );

    this.leftWall = new GameWall(
      this,
      0,
      this.game.config.height - this.leftSquare.height,
      "top",
      new Phaser.Math.Vector2(1, 1)
    );
    this.rightWall = new GameWall(
      this,
      this.game.config.width,
      this.game.config.height - this.leftSquare.height,
      "top",
      new Phaser.Math.Vector2(0, 1)
    );

    this.square = new PlayerSquare(
      this,
      this.game.config.width / 2,
      -400,
      "square",
      tintColor
    );
    this.square.updateText(this.saveData.level);

    this.help = new HelpInfo(this);

    this.updateLevel();

    this.input.on("pointerdown", this.grow, this);
    this.input.on("pointerup", this.stop, this);
    this.gameMode = gameMode.IDLE;
  }
  afterBackTop() {
    this.gameMode = gameMode.WAITING;
    if (this.square.successful == 0) {
      this.help.show();
    }
    this.help.setTargetSize();
  }

  updateLevel() {
    this.holeWidth = Phaser.Math.Between(
      GAMEOPTIONS.holeWidthRange[0],
      GAMEOPTIONS.holeWidthRange[1]
    );
    this.wallWidth = Phaser.Math.Between(
      GAMEOPTIONS.wallRange[0],
      GAMEOPTIONS.wallRange[1]
    );
    this.leftSquare.tweenTo((this.game.config.width - this.holeWidth) / 2);
    this.rightSquare.tweenTo((this.game.config.width + this.holeWidth) / 2);
    this.leftWall.tweenTo(
      (this.game.config.width - this.holeWidth) / 2 - this.wallWidth
    );
    this.rightWall.tweenTo(
      (this.game.config.width + this.holeWidth) / 2 + this.wallWidth
    );
    this.square.back();
  }
  grow() {
    if (this.gameMode != gameMode.WAITING) return;
    this.gameMode = gameMode.GROWING;
    this.help.hide();
    this.square.grow();
  }

  stop() {
    this.gameMode = gameMode.IDLE;
    this.square.stop();
  }
  afterStoped() {
    if (this.square.successful == this.saveData.level) {
      this.saveData.level++;
      localStorage.setItem(
        GAMEOPTIONS.localStorageName,
        JSON.stringify({
          level: this.saveData.level,
        })
      );
      this.scene.start("PlayGame");
    } else {
      this.square.updateText(this.saveData.level - this.square.successful);
      this.help.setLevelText(this.saveData.level);
      this.updateLevel();
    }
  }

  gameOver() {
    this.time.addEvent({
      delay: 1000,
      callback: () => {
        this.scene.start("PlayGame");
      },
      callbackScope: this,
    });
  }
}
