import {GAMEOPTIONS} from './GameOptions.js'
import * as gameMode from './GameModes.js'
import PlayerSquare from './PlayerSquare.js'
import SquareText from './SquareText.js'
import GameWall from './GameWall.js'

export default class PlayGame extends Phaser.Scene {
	constructor() {
		super("PlayGame")
	}
    create() {
        this.saveData = localStorage.getItem(GAMEOPTIONS.localStorageName) == null ? { level: 1} : JSON.parse(localStorage.getItem(GAMEOPTIONS.localStorageName));
        let tintColor = Phaser.Utils. Array.GetRandom(GAMEOPTIONS.bgColors);
        this.cameras.main.setBackgroundColor(tintColor);
        this.leftSquare = new GameWall(this, 0, this.game.config.height, "base", new Phaser.Math.Vector2(1, 1));
        this.add.existing(this.leftSquare);
        this.rightSquare = new GameWall(this, this.game.config.width, this.game.config.height, "base", new Phaser.Math.Vector2(0, 1));
        this.add.existing(this.rightSquare);
        this.leftWall = new GameWall(this, 0, this.game.config.height - this.leftSquare.height, "top", new Phaser.Math.Vector2(1, 1));
        this.add.existing(this.leftWall);
        this.rightWall = new GameWall(this, this.game.config.width, this.game.config.height - this.leftSquare.height, "top", new Phaser.Math.Vector2(0, 1));
        this.add.existing(this.rightWall);
        this.square = new PlayerSquare(this, this.game.config.width / 2, -400, "square");
		this.add.existing(this.square);
		this.squareText = new SquareText(this, this.square.x, this.square.y, "font", this.saveData.level, 120, tintColor);
		this.add.existing(this.squareText);
        this.squareTweenTargets = [this.square, this.squareText];
        this.levelText = this.add.bitmapText(this.game.config.width / 2, 0, "font", "level " + this.saveData.level, 60);
        this.levelText.setOrigin(0.5, 0);
        this.updateLevel();
        this.input.on("pointerdown", this.grow, this);
        this.input.on("pointerup", this.stop, this);
        this.gameMode = gameMode.IDLE;
	}
    updateLevel() {
        let holeWidth = Phaser.Math.Between(GAMEOPTIONS.holeWidthRange[0], GAMEOPTIONS.holeWidthRange[1]);
        let wallWidth = Phaser.Math.Between(GAMEOPTIONS.wallRange[0], GAMEOPTIONS.wallRange[1]);
        this.leftSquare.tweenTo((this.game.config.width - holeWidth) / 2);
        this.rightSquare.tweenTo((this.game.config.width + holeWidth) / 2);
        this.leftWall.tweenTo((this.game.config.width - holeWidth) / 2 - wallWidth);
        this.rightWall.tweenTo((this.game.config.width + holeWidth) / 2 + wallWidth);
        let squareTween = this.tweens.add({
            targets: this.squareTweenTargets,
            y: 150,
            scaleX: 0.2,
            scaleY: 0.2,
            angle: 50,
            duration: 500,
            ease: "Cubic.easeOut",
            callbackScope: this,
            onComplete: function() {
                this.rotateTween = this.tweens.add({
                    targets: this.squareTweenTargets,
                    angle: 40,
                    duration: 300,
                    yoyo: true,
                    repeat: -1
                });
                if (this.square.successful == 0) {
                    this.addInfo(holeWidth, wallWidth);
                }
                this.gameMode = gameMode.WAITING;
            }
        })
    }
    grow() {
        if (this.gameMode == gameMode.WAITING) {
            this.gameMode = gameMode.GROWING;
            if (this.square.successful == 0) {
                this.infoGroup.toggleVisible();
            }
            this.growTween = this.tweens.add({
                targets: this.squareTweenTargets,
                scaleX: 1,
                scaleY: 1,
                duration: GAMEOPTIONS.growTime
            });
        }
    }
    stop() {
        if (this.gameMode == gameMode.GROWING) {
            this.gameMode = gameMode.IDLE;
            this.growTween.stop();
            this.rotateTween.stop();
            this.rotateTween = this.tweens.add({
                targets: this.squareTweenTargets,
                angle: 0,
                duration:300,
                ease: "Cubic.easeOut",
                callbackScope: this,
                onComplete: function(){
                    if (this.square.displayWidth <= this.rightSquare.x - this.leftSquare.x) {
                        this.tweens.add({
                            targets: this.squareTweenTargets,
                            y: this.game.config.height + this.square.displayWidth,
                            duration:600,
                            ease: "Cubic.easeIn",
                            callbackScope: this,
                            onComplete: function(){
                                this.levelText.text = "Oh no!!!";
                                this.gameOver();
                            }
                        })
                    }
                    else{
                        if (this.square.displayWidth <= this.rightWall.x - this.leftWall.x) {
                            this.fallAndBounce(true);
                        }
                        else{
                            this.fallAndBounce(false);
                        }
                    }
                }
            })
        }
    }
    fallAndBounce(success) {
        let destY = this.game.config.height - this.leftSquare.displayHeight - this.square.displayHeight / 2;
        let message = "Yeah!!!!";
        if (success) {
            this.square.successful ++;
        }
        else {
            destY = this.game.config.height - this.leftSquare.displayHeight - this.leftWall.displayHeight - this.square.displayHeight / 2;
            message = "Oh no!!!!";
        }
        this.tweens.add({
            targets: this.squareTweenTargets,
            y: destY,
            duration:600,
            ease: "Bounce.easeOut",
            callbackScope: this,
            onComplete: function(){
                this.levelText.text = message;
                if (!success) {
                    this.gameOver();
                }
                else{
                    this.time.addEvent({
                        delay: 1000,
                        callback: function(){
                            if (this.square.successful == this.saveData.level) {
                                this.saveData.level ++;
                                localStorage.setItem(GAMEOPTIONS.localStorageName, JSON.stringify({
                                    level: this.saveData.level
                                }));
                                this.scene.start("PlayGame");
                            }
                            else {
                                this.squareText.updateText(this.saveData.level - this.square.successful);
                                this.levelText.text = "level " + this.saveData.level;
                                this.updateLevel();
                            }
                        },
                        callbackScope: this
                    });
                }
            }
        })
    }
    addInfo(holeWidth, wallWidth) {
        this.infoGroup = this.add.group();
        let targetSquare = this.add.sprite(this.game.config.width / 2, this.game.config.height - this.leftSquare.displayHeight, "square");
        targetSquare.displayWidth = holeWidth + wallWidth;
        targetSquare.displayHeight = holeWidth + wallWidth;
        targetSquare.alpha = 0.3;
        targetSquare.setOrigin(0.5, 1);
        this.infoGroup.add(targetSquare);
        let targetText = this.add.bitmapText(this.game.config.width / 2, targetSquare.y - targetSquare.displayHeight - 20, "font", "land here", 48);
        targetText.setOrigin(0.5, 1);
        this.infoGroup.add(targetText);
        let holdText = this.add.bitmapText(this.game.config.width / 2, 250, "font", "tap and hold to grow", 40);
        holdText.setOrigin(0.5, 0);
        this.infoGroup.add(holdText);
        let releaseText = this.add.bitmapText(this.game.config.width / 2, 300, "font", "release to drop", 40);
        releaseText.setOrigin(0.5, 0);
        this.infoGroup.add(releaseText);
    }
    gameOver() {
        this.time.addEvent({
            delay: 1000,
            callback: function() {
                this.scene.start("PlayGame");
            },
            callbackScope: this
        });
    }
}
