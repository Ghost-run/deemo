import Bullet from "./Bullet.js";
import WeaponBase from "./WeaponBase.js";
export default class WeaponThreeWay extends WeaponBase {
  constructor(scene) {
    super( scene,['bullet5'] );

  }

  fire_bullets(x, y) {

    let bullet = this.getFirstDead(false);
    if (!!bullet) bullet.fire(x, y, 30, this.bulletSpeed, 0, 0);
    bullet = this.getFirstDead(false);
    if (!!bullet) bullet.fire(x, y, 0, this.bulletSpeed, 0, 0);
    bullet = this.getFirstDead(false);
    if (!!bullet) bullet.fire(x, y, -30, this.bulletSpeed, 0, 0);
  }
  
}
