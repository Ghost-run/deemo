import Bullet from "./Bullet.js";

export default class WeaponBase extends Phaser.Physics.Arcade.Group {
  constructor(scene, key) {
    super(scene.physics.world, scene);
    this.key = key;
    this.name = this.constructor.name;
    this.scene = scene;
    this.nextFire = 0;
    this.bulletSpeed = 600;
    this.fireRate = 100;
    this.createBullets();
  }
  createBullets() {
    let items=this.createMultiple({
      classType: Bullet, // This is the class we create just below
      frameQuantity:10,
      //quantity: 20,
      max: 60,
      active: false,
      visible: false,
      randomKey: true,
     // runChildUpdate: true,
      key: this.key,
    });
   // this.addMultiple(items, true);
  }
  fire_bullets(x, y) {
    let bullet = this.getFirstDead(false);
    if (!!bullet) bullet.fire(x, y, 0, this.bulletSpeed, 0, 0);
  }
  fire(source) {
    if (this.scene.time.time < this.nextFire) {
      return;
    }

    let x = source.x + 10;
    let y = source.y + 10;

    this.fire_bullets(x, y);

    this.nextFire = this.scene.time.time + this.fireRate;
  }

  update(time, delta) {
    for (let bullet of this.getChildren()) {

      if (!bullet.active) continue;

      bullet.update(time, delta);
      if (
        bullet.x > this.scene.scale.width ||
        bullet.y > this.scene.scale.height ||
        bullet.x < 0 ||
        bullet.y < 0
      ) {
        bullet.disableBody(true, true);
        this.killAndHide(bullet);
        bullet.x = 10;
        bullet.y = 10;
        // console.log(this.countActive(false))
      }
    }
  }
}
