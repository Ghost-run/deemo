import Bullet from "./Bullet.js";
import WeaponBase from "./WeaponBase.js";
export default class WeaponRockets extends WeaponBase {
  constructor(scene) {
    super( scene,'bullet10');
  }

  fire_bullets(x, y) {
    let bullet = this.getFirstDead(false);
    if (!!bullet){
      bullet.tracking=true;
      bullet.fire(x, y, 0, this.bulletSpeed, 0, -700);
    }

    bullet = this.getFirstDead(false);
    if (!!bullet){
      bullet.tracking=true;
      bullet.fire(x, y, 0, this.bulletSpeed, 0, 700);
    }

  }
  
}
