import WeaponBase from "./WeaponBase.js";
import WeaponThreeWay from "./WeaponThreeWay.js";
import WeaponRockets from "./WeaponRockets.js";
import WeaponScale from "./WeaponScale.js";
export default class MyGame extends Phaser.Scene {
  constructor() {
    super("mygame");
    this.background = null;
    this.foreground = null;

    this.player = null;
    this.cursors = null;
    this.speed = 300;

    this.weapons = [];
    this.currentWeapon = 0;
    this.weaponName = null;
  }
  preload() {
    this.load.crossOrigin = "anonymous";
    this.load.setPath("assets/");

    this.load.image("background", "back.png");
    this.load.image("foreground", "fore.png");
    this.load.image("player", "ship.png");
    this.load.bitmapFont(
      "shmupfont",
      "shmupfont.png",
      "shmupfont.xml"
    );

    for (let i = 1; i <= 11; i++) {
      this.load.image("bullet" + i, "bullet" + i + ".png");
    }
  }
  create() {
    this.background = this.add.tileSprite(
      this.scale.width / 2,
      this.scale.height / 2,
      this.scale.width,
      this.scale.height,
      "background"
    );

    this.background.depth = 0;

    this.player = this.physics.add.image(64, 200, "player");
    this.player.depth = 1;

    this.player.body.collideWorldBounds = true;

    this.foreground = this.add.tileSprite(
      0,
      0,
      this.scale.width,
      this.scale.height,
      "foreground"
    );
    this.foreground.setOrigin(0, 0);
    this.foreground.depth = 3;

    this.weaponName = this.add.bitmapText(
      8,
      364,
      "shmupfont",
      "SPACE = Next Weapon",
      24
    );
    this.weaponName.depth = 10;

    this.weapons.push(new WeaponBase(this,['bullet1','bullet2','bullet3']));
    this.weapons.push(new WeaponThreeWay(this));
    this.weapons.push(new WeaponRockets(this));
    this.weapons.push(new WeaponScale(this));
    this.cursors = this.input.keyboard.createCursorKeys();
    this.input.on('pointerdown', (pointer)=>{
      this.fire(this.player);
      });
    this.input.keyboard.on("keydown-SPACE", this.nextWeapon, this);

  
  }
  fire() {
    this.weapons[this.currentWeapon].fire(this.player);
  }
  nextWeapon() {
    this.currentWeapon=(this.currentWeapon+1)%this.weapons.length;
    this.weapons[this.currentWeapon].visible = true;
    this.weaponName.text = this.weapons[this.currentWeapon].name;
  }
  update(time, delta) {
    this.background.tilePositionX += 1;
    this.foreground.tilePositionX += 3;
    this.player.body.velocity.set(0);

    if (this.cursors.left.isDown) {
      this.player.body.velocity.x = -this.speed;
    } else if (this.cursors.right.isDown) {
      this.player.body.velocity.x = this.speed;
    }

    if (this.cursors.up.isDown) {
      this.player.body.velocity.y = -this.speed;
    } else if (this.cursors.down.isDown) {
      this.player.body.velocity.y = this.speed;
    }
    this.weapons[this.currentWeapon].update(time, delta);
  }
}
