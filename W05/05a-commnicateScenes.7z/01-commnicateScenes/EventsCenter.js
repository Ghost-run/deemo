const eventsCenter = new Phaser.Events.EventEmitter()

export default eventsCenter