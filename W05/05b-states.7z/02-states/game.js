import Play from "./Play.js";
const config = {
    type: Phaser.WEBGL,
    width: 400,
    height: 300,
    pixelArt: true,
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
    },
    parent: "mygame",
    physics: {
        default: 'arcade'
    },
    backgroundColor: '#4488aa',
    scene: [Play]
};
 
export default new Phaser.Game(config);