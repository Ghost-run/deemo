import PreloadAssets from './scenes/PreloadAssets.js'
import PlayGame from './scenes/PlayGame.js'
const config = {
    type: Phaser.AUTO,
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
        parent: "mygame",
        width: 640,
        height: 960
    },
    backgroundColor: '#4488aa',
    scene: [PreloadAssets, PlayGame]
}
 
export default new Phaser.Game(config)