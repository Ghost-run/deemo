export default class GameWall extends Phaser.GameObjects.Sprite {
	constructor(scene, x, y, key, origin) {
		super(scene, x, y, key);
        this.setOrigin(origin.x, origin.y);
        scene.add.existing(this);
	}

    tweenTo(x) {
        this.scene.tweens.add({
            targets: this,
            x: x,
            duration: 500,
            ease: "Cubic.easeOut"
        });
    }
}
