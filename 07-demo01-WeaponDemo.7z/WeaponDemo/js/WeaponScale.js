import Bullet from "./Bullet.js";
import WeaponBase from "./WeaponBase.js";
export default class WeaponScale extends WeaponBase {
  constructor(scene) {
    super( scene,'bullet9');
    // this.children.each((child) => {
    //   child.scaleSpeed = 0.5;
    //   console.log(child.scaleSpeed);
    // },this);

  }

  fire_bullets(x, y) {
    let bullet = this.getFirstDead(false);
    if (!!bullet) {
      bullet.scaleSpeed = 0.08;
      bullet.fire(x, y, 0, this.bulletSpeed, 0, 0);
    }
  }
  
}
