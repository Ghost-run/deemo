import { GAMEOPTIONS } from "./GameOptions.js";
export default class HelpInfo {
  constructor(scene) {
    this.scene = scene;
    this.levelText = scene.add.bitmapText(
      scene.game.config.width / 2,
      0,
      "font",
      "level " + scene.saveData.level,
      60
    );
    this.levelText.setOrigin(0.5, 0);
    this.addInfo();
  }
  setLevelText(level) {
    this.levelText.text = "level " + level;
  }
  show(){
    this.tipGroup.setVisible(true, 0, 1);
  }
  hide() {
    this.targetSquare.setVisible(false);
    this.tipGroup.setVisible(false, 0, 1);
  }
  setTargetSize() {
    this.targetSquare.displayWidth =
      this.scene.holeWidth + this.scene.wallWidth;
    this.targetSquare.displayHeight =
      this.scene.holeWidth + this.scene.wallWidth;
    this.targetSquare.setVisible(true);
  }
  addInfo() {
    let scene = this.scene;
    this.tipGroup = scene.add.group();
    let targetSquare = scene.add.sprite(
        scene.game.config.width / 2,
        scene.game.config.height - scene.leftSquare.displayHeight,
      "square"
    );
    targetSquare.displayWidth = 0;
    targetSquare.displayHeight = 0;

    targetSquare.alpha = 0.3;
    targetSquare.setOrigin(0.5, 1);

    this.targetSquare = targetSquare;

    let targetText = scene.add.bitmapText(
        scene.game.config.width / 2,
      targetSquare.y - targetSquare.displayHeight - 20,
      "font",
      "land here",
      48
    );
    targetText.setOrigin(0.5, 1);
    this.tipGroup.add(targetText);

    let holdText = scene.add.bitmapText(
        scene.game.config.width / 2,
      250,
      "font",
      "tap and hold to grow",
      40
    );
    holdText.setOrigin(0.5, 0);
    this.tipGroup.add(holdText);
    let releaseText = scene.add.bitmapText(
        scene.game.config.width / 2,
      300,
      "font",
      "release to drop",
      40
    );
    releaseText.setOrigin(0.5, 0);
    this.tipGroup.add(releaseText);
  }
}
