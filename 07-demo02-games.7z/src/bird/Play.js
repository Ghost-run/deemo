let gameOptions = {

    // bird gravity, will make bird fall if you don't flap
    birdGravity: 800,

    // horizontal bird speed
    birdSpeed: 125,

    // flap thrust
    birdFlapPower: 300,

    // minimum pipe height, in pixels. Affects hole position
    minPipeHeight: 50,

    // distance range from next pipe, in pixels
    pipeDistance: [180, 220],

    // hole range between pipes, in pixels
    pipeHole: [110, 150],

    // local storage object name
    localStorageName: 'bestFlappyScore'
}
export default class Play extends Phaser.Scene {
    constructor() {
        super('play');
    }
    preload() {
        this.load.setPath('../assets')
        this.load.spritesheet('bird', 'bird.png', { frameWidth: 34, frameHeight: 24 });
        this.load.spritesheet('pipes', 'pipes.png', { frameWidth: 54, frameHeight: 320 });
        //加载音效
        this.load.audio('score', 'score.wav');
        this.load.audio('ground-hit', 'ground-hit.wav');
        this.load.audio('pipe-hit', 'pipe-hit.wav');
    }
    create() {
        this.anims.create({
            key: 'fly',
            frames: this.anims.generateFrameNumbers('bird', { start: 0, end: 2 }),
            frameRate: 10,
            repeat: -1,
        });

        this.bird = this.physics.add.sprite(80, this.scale.height / 2, 'bird');
        this.bird.body.gravity.y = gameOptions.birdGravity;
        this.bird.anims.play('fly');
        this.input.on('pointerdown', this.flap, this);
        this.score = 0;
        this.topScore = localStorage.getItem(gameOptions.localStorageName) == null ? 0 : localStorage.getItem(gameOptions.localStorageName);
        this.scoreText = this.add.text(10, 10, '');
        this.updateScore(this.score);

        this.pipeGroup = this.physics.add.group();
        this.pipePool = [];
        for (let i = 0; i < 4; i++) {
            this.pipePool.push(this.pipeGroup.create(0, 0, 'pipes',0));
            this.pipePool.push(this.pipeGroup.create(0, 0, 'pipes',1));
            this.placePipes(false);
        }
        this.pipeGroup.setVelocityX(-gameOptions.birdSpeed);
        this.physics.add.collider(this.bird, this.pipeGroup,()=>{
            this.sound.play('pipe-hit');
            this.die();
        }, null, this );

    }
    updateScore(inc) {
        this.sound.play('score');
        this.score += inc;
        this.scoreText.text = 'Score: ' + this.score + '\nBest: ' + this.topScore;

    }

    flap() {
        this.bird.angle = 0;
        this.bird.body.velocity.y = -gameOptions.birdFlapPower;
        this.tweens.add({
            targets: this.bird,
            duration: 100,
            angle: -30,
        })
    }
    update() {
 
        if (this.bird.y > this.scale.height || this.bird.y < 0) {
            this.sound.play('ground-hit');
            this.die();
        }
        if (this.bird.angle < 90) this.bird.angle += 1;
        this.pipeGroup.children.each((pipe) => {
            if (pipe.getBounds().right < 0) {
                this.pipePool.push(pipe);
                if (this.pipePool.length == 2) {
                    this.placePipes(true);

                }
            }
        }, this)
    }
    die() {
        localStorage.setItem(gameOptions.localStorageName, Math.max(this.score, this.topScore));
        this.scene.start('play');
    }
    placePipes(addScore) {
        let rightmost = this.getRightmostPipe();
        let pipeHoleHeight = Phaser.Math.Between(gameOptions.pipeHole[0], gameOptions.pipeHole[1]);
        let top = gameOptions.minPipeHeight + pipeHoleHeight / 2;
        let pipeHolePosition = Phaser.Math.Between(top, this.scale.height - top);
        this.pipePool[0].x = rightmost + this.pipePool[0].getBounds().width + Phaser.Math.Between(gameOptions.pipeDistance[0], gameOptions.pipeDistance[1]);
        this.pipePool[0].y = pipeHolePosition - pipeHoleHeight / 2;
        this.pipePool[0].setOrigin(0, 1);
        this.pipePool[1].x = this.pipePool[0].x;
        this.pipePool[1].y = pipeHolePosition + pipeHoleHeight / 2;
        this.pipePool[1].setOrigin(0, 0);
        this.pipePool = [];
        if (addScore) {
            this.updateScore(1);
        }
    }
     //获取最右边的管道横坐标
     getRightmostPipe() {
        let rightmostPipe = 0;
        this.pipeGroup.children.each((pipe) => {
            rightmostPipe = Math.max(rightmostPipe, pipe.x);
        });
        //console.log(rightmostPipe);
        return rightmostPipe;
    }
}