/// <reference path="./phaser.d.ts"/>

import CatchTheCatGame from "./game";

window["CatchTheCatGame"] = CatchTheCatGame;
