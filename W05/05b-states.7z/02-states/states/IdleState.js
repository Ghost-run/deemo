import  {State} from "./StateMachine.js";

export default class IdleState extends State {
    enter(scene, hero) {
      hero.setVelocity(0);
      hero.anims.play(`walk-${hero.direction}`);
      hero.anims.stop();
    }
    
    execute(scene, hero) {
      const {left, right, up, down, space, shift} = scene.keys;
      
      // Transition to swing if pressing space
      if (space.isDown) {
        this.stateMachine.transition('swing');
        return;
      }
      
      // Transition to dash if pressing shift
      if (shift.isDown) {
        this.stateMachine.transition('dash');
        return;
      }
      
      // Transition to move if pressing a movement key
      if (left.isDown || right.isDown || up.isDown || down.isDown) {
        this.stateMachine.transition('move');
        return;
      }
    }
  }