import  StateMachine from "./states/StateMachine.js";
import  IdleState  from "./states/IdleState.js";
import MoveState from "./states/MoveState.js";
import SwingState from "./states/SwingState.js";
import DashState from "./states/DashState.js";

export default class Play extends Phaser.Scene {
  constructor() {
    super("Play");

  }
  preload() {
    this.load.spritesheet('hero', './assets/hero.png', {
        frameWidth: 32,
        frameHeight: 32,
      });
      this.load.image('bg', './assets/bg.png');
 
  }
  create() {

      this.keys = this.input.keyboard.createCursorKeys();
        
      // Static background
      this.add.image(200, 200, 'bg');
      
      // The movable character
      this.hero = this.physics.add.sprite(200, 150, 'hero', 0);
      this.hero.direction = 'down';
      
      // The state machine managing the hero
      this.stateMachine = new StateMachine('idle', {
        idle: new IdleState(),
        move: new MoveState(),
        swing: new SwingState(),
        dash: new DashState(),
      }, [this, this.hero]);
      
      
      // Animation definitions
      this.anims.create({
        key: 'walk-down',
        frameRate: 8,
        repeat: -1,
        frames: this.anims.generateFrameNumbers('hero', {start: 0, end: 3}),
      });
      this.anims.create({
        key: 'walk-right',
        frameRate: 8,
        repeat: -1,
        frames: this.anims.generateFrameNumbers('hero', {start: 4, end: 7}),
      });
      this.anims.create({
        key: 'walk-up',
        frameRate: 8,
        repeat: -1,
        frames: this.anims.generateFrameNumbers('hero', {start: 8, end: 11}),
      });
      this.anims.create({
        key: 'walk-left',
        frameRate: 8,
        repeat: -1,
        frames: this.anims.generateFrameNumbers('hero', {start: 12, end: 15}),
      });
      
      // NOTE: Sword animations do not repeat
      this.anims.create({
        key: 'swing-down',
        frameRate: 8,
        repeat: 0,
        frames: this.anims.generateFrameNumbers('hero', {start: 16, end: 19}),
      });
      this.anims.create({
        key: 'swing-up',
        frameRate: 8,
        repeat: 0,
        frames: this.anims.generateFrameNumbers('hero', {start: 20, end: 23}),
      });
      this.anims.create({
        key: 'swing-right',
        frameRate: 8,
        repeat: 0,
        frames: this.anims.generateFrameNumbers('hero', {start: 24, end: 27}),
      });
      this.anims.create({
        key: 'swing-left',
        frameRate: 8,
        repeat: 0,
        frames: this.anims.generateFrameNumbers('hero', {start: 28, end: 31}),
      });
    }
    
    update() {
      this.stateMachine.step();
    }
  }


