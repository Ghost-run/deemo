export const IDLE = 0;
export const WAITING = 1;
export const GROWING = 2;
