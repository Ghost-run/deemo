import PlayScene from "./PlayScene.js";
import UIScene from "./UIScene.js";
//https://blog.ourcade.co/posts/2020/phaser3-how-to-communicate-between-scenes/


let config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    backgroundColor: "#000000",
    scene: [PlayScene, UIScene],
  };
  
  let game = new Phaser.Game(config);