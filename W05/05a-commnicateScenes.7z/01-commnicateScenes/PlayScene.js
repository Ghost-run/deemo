

import eventsCenter from "./EventsCenter.js";

export default class PlayScene extends Phaser.Scene {
  constructor() {
    super("play-scene");
  }

  // then later in the Game Scene file
  create() {
    this.count = 0;

    this.scene.run("ui-scene");

    this.input.keyboard.on("keydown-SPACE", () => {
      ++this.count;
      console.log(this.count);

      eventsCenter.emit("update-count", this.count);
    });

    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      this.input.keyboard.off("keydown-SPACE");
    });
  }
}
