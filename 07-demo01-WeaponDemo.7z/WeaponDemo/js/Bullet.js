export default class Bullet extends Phaser.Physics.Arcade.Image {
  constructor(scene, x, y, key) {
    super(scene, x, y, key);
    this.setActive(false);
    this.setVisible(false);
    this.setDepth(1);

    this.tracking = false;
    this.scaleSpeed = 0;
    this.lifespan = 1000;
  }
  fire(x, y, angle, speed, gx, gy) {
    this.lifespan = 1000;
    gx = gx || 0;
    gy = gy || 0;

    this.enableBody(true, x, y, true, true);
    this.setScale(1);
    //this.refreshBody();
    //let rot = Phaser.Math.DegToRad(degree);
    this.scene.physics.velocityFromAngle(angle, speed, this.body.velocity);
    this.angle = angle;
    this.body.gravity.set(gx, gy);
  }

  update(time, delta) {
   // console.log(this.tracking)
    if (this.tracking) {
      this.rotation = Math.atan2(this.body.velocity.y, this.body.velocity.x);
      //console.log(this.rotation);
    }

    if (this.scaleSpeed > 0) {
      
      this.scaleX += this.scaleSpeed;
      this.scaleY += this.scaleSpeed;
      if (this.scaleX>3)  {
        this.scaleX=3;
      }
      if (this.scaleY>3)  {
        this.scaleY=3;
      }
      //this.refreshBody();
    }
    this.lifespan -= delta;

    if (this.lifespan <= 0) {
      this.disableBody(true, true);
      this.lifespan = 1000;
    }
  }
}
