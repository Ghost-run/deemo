export default function idiotSolver(blocksIsWall: boolean[][], i: number, j: number): number {
    return -1;
}
