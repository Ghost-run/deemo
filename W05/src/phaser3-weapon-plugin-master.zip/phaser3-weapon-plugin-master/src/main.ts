// Set up shortcuts to the classes and constants
export { default as Weapon } from './Weapon';
export { default as Bullet } from './Bullet';
export { default as consts } from './consts';
export { default as events } from './events';
export { default as WeaponPlugin } from './WeaponPlugin';
